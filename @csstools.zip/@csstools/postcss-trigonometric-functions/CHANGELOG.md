# Changes to PostCSS Trigonometric Functions

### 1.0.2 (July 8, 2022)

- Fix case insensitive matching.

### 1.0.1 (May 31, 2022)

- Ensure that the plugin works in node 14

### 1.0.0 (May 20, 2022)

- Initial version
