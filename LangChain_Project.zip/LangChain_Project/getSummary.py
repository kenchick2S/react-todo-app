from langchain_core.prompts import ChatPromptTemplate

class getSummary:

    
    def __init__(self, llm):
        self.llm = llm
    
    def store_dataset(self, dataset):
        self.dataset = dataset
        print(f"Dataset Type: {type(self.dataset)}")
        return self.dataset
    
    # Summarize the key characteristics of this datasets, Include basic statistics and data insights.
    def summary(self, msg):
        try:
            system = f'''
                I want you to act as a data scientist.
                Don't give me any code for programming.
                (If ask to do calculating, Just list all relative number, then compute step by step as example.
                    example:
                    Question: 1+1+2+3+4 = ?
                    Thought:
                    1+1 = 2,
                    2+2 = 4,
                    4+3 = 7,
                    7+4 = 11
                    Answer: 11)
                Here is raw data:
                ===
                {self.dataset.to_string(index=False)}
                ===
                '''

            human = '''{input}

                (Please respond in traditional chinese.)'''

            prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", system),
                    ("human", human),
                ]
            )
            print("Summarizing ...")
            return self.llm.invoke(prompt.format(input=msg))
        except:
            return "無法做資料分析"
    
    def get_dataset(self):
        try:
            return self.dataset
        except:
            return "無法做資料分析"