import { useState } from 'react'

import './FunctionDialog.css'

export default function FunctionDialog(){

    const [Clicked, setClicked] = useState(false);

    return(
        <div className="testbox1">
            {Clicked && 
                <div role="dialog" className="dialog1">
                    <input type="checkbox"></input>
                </div>
            }
            <div role="button" className="btn1" onClick={() => setClicked(!Clicked)}>123</div>
        </div>
    )
}